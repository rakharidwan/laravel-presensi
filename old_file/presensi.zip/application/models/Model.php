<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Model extends CI_Model
{
    public function GetUser($data) {
        $query = $this->db->get_where('tb_login', $data);
        return $query;
    }

    public function GetJab($where= "")
    {
        $data = $this->db->query('select * from tb_jabatan '.$where);
        return $data;
    }

    public function GetKaryawan($where= "")
    {
        $data = $this->db->query('select * from tb_karyawan '.$where);
        return $data;
    }

    public function GetAdmin($where= "")
    {
        $data = $this->db->query('select * from tb_login '.$where);
        return $data;
    }

    public function GetTotKaryawan()
    {
        $data = $this->db->query('select * from tb_karyawan group by id_jab ');
        return $data;
    }

    public function GetDetAbsensi($where = ""){
        return $this->db->query("select tb_absensi.*, tb_karyawan.*, tb_jabatan.* from tb_karyawan inner join tb_absensi on tb_absensi.nippos=tb_karyawan.nippos $where;");
    }

    public function count_all() {
        return $this->db->count_all('tb_karyawan');
    }

    public function GetKaryawanJabAbs($where= "") {
    $data = $this->db->query('SELECT p.*, q.jabatan, r.*
                                FROM tb_karyawan p
                                INNER JOIN tb_absensi r
                                ON(p.nippos = r.nippos)
                                INNER JOIN tb_jabatan q
                                ON(p.id_jab = q.id_jab)'.$where);
    return $data;
    }

    public function GetKaryawanAbs($where= "") {
    $data = $this->db->query('SELECT p.*, r.*
                                FROM tb_karyawan p
                                INNER JOIN tb_absensi r
                                ON(p.nippos = r.nippos)'.$where);
    return $data;
    }

    public function GetKaryawanJabAbsDet($where= "") {
    $data = $this->db->query('SELECT p.*, q.*, r.*
                                FROM tb_karyawan p
                                INNER JOIN tb_absensi r
                                ON(p.nippos = r.nippos)
                                INNER JOIN tb_jabatan q
                                ON(p.id_jab = q.id_jab)'.$where);
    return $data;
    }

    public function GetKaryawanJab($where= "") {
    $data = $this->db->query('SELECT p.*, q.jabatan
                                FROM tb_karyawan p
                                LEFT JOIN tb_jabatan q
                                ON(p.id_jab = q.id_jab)'.$where);
    return $data;
    }

    public function Simpan($table, $data){
        return $this->db->insert($table, $data);
    }

    public function Update($table,$data,$where){
        return $this->db->update($table,$data,$where);
    }

    public function Hapus($table,$where){
        return $this->db->delete($table,$where);
    }

    public function UpdateKaryawan($data){
        $this->db->where('id_kar',$data['id_kar']);
        $this->db->update('tb_karyawan',$data);
    }

    public function GetProductView(){
        return $this->db->query("select sum(counter) as totalview from tb_karyawan where status = 'publish'");
    }

    public function GetJabe($where= "")
    {
        $data = $this->db->query('select count(*) as totaljabatan from tb_jabatan '.$where);
        return $data;
    }

    public function TotalKat(){
        return $this->db->query("select count(*) as totaljabatan from tb_karyawan group by id_jab; ");
    }

    public function cekkaryawantidakhadir($nippos){
        $tanggal = date("Y-m-d");       
        $array = array('nippos' => $nippos, 'tanggal' => $tanggal); 
        $this->db->where($array);
        $query = $this->db->get('tb_absensi');
        return $query;
    }

    public function inputyangbelumngisipresensi($nippos){
        $tanggal = date("Y-m-d");
        $data = $this->db->query("select * from tb_absensi where nippos = '$nippos' tanggal = '$tanggal'");
        return $data;
    }

}