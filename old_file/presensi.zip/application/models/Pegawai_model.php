<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Pegawai_model extends CI_Model
{
     
    public function cekNikPegawai(){
        $nippos=$this->input->post('nippos');
        $query=$this->db->query("select nippos from tb_karyawan where nippos='$nippos'");
        return $query->num_rows();
    }

    public function cekMasuk(){
        $nippos=$this->input->post('nippos');
        $datenow=date("Y-m-d");
        $ceknippos=$this->cekNikPegawai();
        if($ceknippos==0){
            echo'<hr><label style="font-size:20px;font-family:calibri">NIP yang Anda masukkan salah</label>';
            return false;
        } else {
            $query=$this->db->query("select nippos,jammasuk from tb_absensi where nippos='$nippos' and tanggal='$datenow'");
            if ($query->num_rows() > 0){
                $this->cekPulang();
            } else {
                echo "Masuk";
            }
        }
    }

    public function Masuk(){
        $nippos=$this->input->post('nippos');
        $tanggal = date("Y-m-d");
        $query=$this->db->query("select nippos,jammasuk from tb_absensi where nippos='$nippos' and tanggal='$tanggal'");
        if ($query->num_rows() > 0){
            echo'<hr><label style="font-size:20px;font-family:calibri">'.$namakar.', Anda sudah masuk Pukul:</label><br>';
            echo'<label style="color:green;font-size:25px;font-family:calibri"><br>'.$jammasuk.'</label><br>';
            echo'<hr><label style="font-size:20px;font-family:calibri">yang fokus bekerjanya ya</label><br>';
        } else {
            $pesan=$this->input->post('pesan');
            $jamkerja=mktime(8,1,0,date("m"), date("d"), date("Y"));
            $jammasuk_tsp = mktime(date("H"), date("i"), date("s"), date("m"), date("d"), date("Y"));
            $jammasuk = date("H:i:s", $jammasuk_tsp);
            $selisih = $jammasuk_tsp - $jamkerja;
            $querynama = $this->db->query("select nama_kar from tb_karyawan where nippos='$nippos'");
            foreach ($querynama->result() as $karyawan) {
                $namakar=$karyawan->nama_kar;
            }
            if ($selisih > 0) {
                $keterangan = "TELAT";
                $jamketerlambatan = floor($selisih/3600);
                $sisa = $selisih % 3600;
                $menitketerlambatan = floor($sisa/60);
                $keterlambatan = floor($selisih/60);
                $keterlambatanbaca = $jamketerlambatan." jam ".$menitketerlambatan." menit"; 
            } else {
                $keterangan = "HADIR";
                $keterlambatan = 0;
                $keterlambatanbaca = "";
            }
            $data=array(
                'nippos'=>$nippos,
                'jammasuk'=> $jammasuk,
                'tanggal'=>$tanggal,
                'keterangan' => $keterangan,
                'pesan' => $pesan,
                'keterlambatan' => $keterlambatan,
                'keterlambatanbaca' => $keterlambatanbaca
            );
            $this->db->trans_start();
            $this->db->insert('tb_absensi',$data);
            $this->db->trans_complete(); 
            echo'<hr><label style="font-size:20px;font-family:calibri">Hore! '.$namakar.', Anda berhasil masuk Pukul:</label><br>';
            echo'<label style="color:green;font-size:25px;font-family:calibri"><br>'.$jammasuk.'</label><br>';
            echo'<hr><label style="font-size:20px;font-family:calibri">Selamat bekerja ya!</label><br>';
        }
    }

    public function cekHadir(){
            $nippos=$this->input->post('nippos');
            $datenow=date("Y-m-d");
            $jammasuk="";
            $ceknippos=$this->cekNikPegawai();
            if($ceknippos==0){
                echo'<hr><label style="font-size:20px;font-family:calibri">NIP yang Anda masukkan salah</label>';
                return false;
            }
            $querymasuk=$this->db->query("select * from tb_absensi where nippos='$nippos' and tanggal='$datenow' and jammasuk IS NOT NULL");
            $querynama = $this->db->query("select nama_kar from tb_karyawan where nippos='$nippos'");
            foreach ($querynama->result() as $karyawan) {
                $namakar=$karyawan->nama_kar;
            }
            if ($querymasuk->num_rows() > 0){
                $querykeluar=$this->db->query("select * from tb_absensi where nippos='$nippos' and tanggal='$datenow' and jamkeluar IS NOT NULL");
                    if ($querykeluar->num_rows() > 0){
                    foreach ($querykeluar->result() as $datakeluar) {
                        $jamkeluar=$datakeluar->jamkeluar;
                    }
                    echo'<hr><label style="font-size:20px;font-family:calibri">'.$namakar.', Anda sudah pulang pukul :</label><br>';
                    echo'<label style="color:red;font-size:25px;font-family:calibri"><br>'.$jamkeluar.'</label><br>';
                    echo'<hr><label style="font-size:20px;font-family:calibri">Cepat pulang ya, keluarga nunggu di rumah</label>';
                    return false;
                    }    else { 
                    foreach ($querymasuk->result() as $datamasuk) {
                        $jammasuk=$datamasuk->jammasuk;
                    }
                        echo'<hr><label style="font-size:20px;font-family:calibri">'.$namakar.', Anda sudah masuk Pukul:</label><br>';
                        echo'<label style="color:green;font-size:25px;font-family:calibri"><br>'.$jammasuk.'</label><br>';
                        echo'<hr><label style="font-size:20px;font-family:calibri">yang fokus bekerjanya ya</label><br>';
                    }
            }    else {
                echo'<hr><label style="font-size:20px;font-family:calibri">'.$namakar.', Anda belum mengisi Presensi</label><br>';
            }
        }

    public function savepresensimanual(){
            $nippos=$this->input->post('nippos');
            $tanggal=$this->input->post('tanggal');
            $jammasuk=$this->input->post('jammasuk');
            $jamkeluar = $this->input->post('jamkeluar');
            if ($this->input->post('keterangan')=="LAINNYA") {
                $keterangan = $this->input->post('lainnya');
            } else {
                $keterangan = $this->input->post('keterangan');
            }
            $jamkerja=mktime(8,1,0,date("m"), date("d"), date("Y"));
            $ceknippos=$this->cekNikPegawai();
            if($ceknippos==0){
                $notif = '<div class="alert alert-danger">Kode karyawan tidak tersedia</div>';
                return $notif;
            }
            $query=$this->db->query("select nippos,jammasuk from tb_absensi where nippos='$nippos' and tanggal='$tanggal'");
            if ($query->num_rows() > 0){
                foreach ($query->result() as $data) {
                    $jammasuk=$data->jammasuk;
                }

                $notif = '<div class="alert alert-danger">Kehadiran karyawan pada tanggal yang Anda input telah terisi!</div>';
                return $notif;
            }    else {
                    $jammasuk_tsp = strtotime($jammasuk);
                    $selisih = $jammasuk_tsp - $jamkerja;
                if ($selisih > 0) {
                    $jamketerlambatan = floor($selisih/3600);
                    $sisa = $selisih % 3600;
                    $menitketerlambatan = floor($sisa/60);
                    $keterlambatan = floor($selisih/60);
                 $keterlambatanbaca = $jamketerlambatan." jam ".$menitketerlambatan." menit"; 
                } else {
                    $keterlambatan = 0;
                    $keterlambatanbaca = "";
                }
                 $data=array(
                 'nippos'=>$nippos,
                 'jammasuk'=>$jammasuk,
                 'jamkeluar'=>$jamkeluar,
                 'tanggal'=>$tanggal,
                 'keterangan' => $keterangan,
                 'keterlambatan' => $keterlambatan,
                 'keterlambatanbaca' => $keterlambatanbaca
                );
                $this->db->trans_start();
                $this->db->insert('tb_absensi',$data);
                $this->db->trans_complete(); 
                $notif ='<div class="alert alert-success">Sukses input data presensi!</div><br>';
                return $notif;
            }
        }

    public function cekdatang(){
            $nippos=$this->input->post('nippos');
            $query=$this->db->query("select nippos from tb_karyawan where nippos='$nippos' and  kodeabsensi='1'");
            return $query->num_rows();
        }
    public function cekPulang(){
            $nippos=$this->input->post('nippos');
            $datenow=date("Y-m-d");
            $query=$this->db->query("select * from tb_absensi where nippos='$nippos' and tanggal='$datenow' and jammasuk IS NOT NULL and jamkeluar IS NOT NULL");
            if ($query->num_rows() < 1){
                echo "Pulang";
            }
        }

    public function Pulang(){
            $nippos=$this->input->post('nippos');
            $pesanpost=$this->input->post('pesan');
            $datenow=date("Y-m-d");
            $querynama = $this->db->query("select nama_kar from tb_karyawan where nippos='$nippos'");
            foreach ($querynama->result() as $karyawan) {
                $namakar=$karyawan->nama_kar;
            }
                $query=$this->db->query("select * from tb_absensi where nippos='$nippos' and tanggal='$datenow' and jamkeluar IS NULL");
                foreach ($query->result() as $data) {
                    $pesanawal=$data->pesan;
                }   
                $pesan = $pesanawal." + ".$pesanpost;
                 $data=array(
                 'jamkeluar'=>date("H:i:s"),
                 'pesan'=>$pesan,
                );
                $this->db->trans_start();
                $array = array('nippos' => $nippos, 'tanggal' => $datenow, 'jamkeluar' => NULL);
                $this->db->where($array);
                $this->db->update('tb_absensi',$data);
                $this->db->trans_complete(); 
                echo'<hr><label style="font-size:20px;font-family:calibri">Alhamdulillah, '.$namakar.', Anda pulang Pukul:</label><br>';
                echo'<label style="color:green;font-size:25px;font-family:calibri"><br>'.date("H:i:s").'</label>';
                echo'<hr><label style="font-size:20px;font-family:calibri">Hati-hati di jalan ya!</label><br>';

        }
        
    public function getListpegawai(){
            $query=$this->db->query("select *,tb_karyawan.nama_kar from tb_absensi left join tb_karyawan on tb_absensi.nippos=tb_karyawan.nippos");
             if ($query->num_rows() > 0) {
                foreach ($query->result() as $data) {
                    $menus[]=$data;
                }
                return $menus;
            }
        }
    public function count(){
            $query=$this->db->query("select count(1) as jumlah from tb_absensi");
             if ($query->num_rows() > 0) {
                foreach ($query->result() as $data) {
                    $menus=$data->jumlah;
                }
                return $menus;
            }
        }

    public function countpresensihariini(){
        $hariini['tanggal'] = date("Y-m-d");
            $query=$this->db->get_where("tb_absensi", $hariini);
            return $query->num_rows();
        }
        
    public function count_cuti($id=''){
        $jumlah='';
        $status=$this->session->userdata('STATUS');
        $addTag="";
        if($status!=0){
        $addTag="where t_cuti.nippos='".$this->session->userdata('NIP')."'";    
        }       
        $query=$this->db->query("select count(1) as jumlah from t_cuti $addTag");
             if ($query->num_rows() > 0) {
                foreach ($query->result() as $data) {
                $jumlah=$data->jumlah;
                }
                return $jumlah;
            }
    }

    public function allpegawai(){
        $allkar = $this->db->query("select nippos from tb_karyawan");
        return $allkar;
    }

    
    public function jumlahkaryawan(){
        $query = $this->db->get('tb_karyawan');
        return $query->num_rows();
    }
     

}