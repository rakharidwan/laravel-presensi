<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Admin_model extends CI_Model
{
    public function getLoginData($usr,$psw)
    {
        global $link;
        $u = $this->db->escape_str($usr);        
        $p = md5($this->db->escape_str($psw.$this->config->item("encryption_key")));
        $q_cek_login = $this->db->get_where('tbl_user_login', array('username' => $u,'password' => $p));
        if(count($q_cek_login->result())>0){
            foreach ($q_cek_login->result() as $user) {
                $lembaga = array(
                    'id_lembaga' => $user->id_lembaga,
                    'role' => "Dapur"
                );
            }
            $cekdapur = $this->db->get_where('tbl_lembaga', $lembaga);
            if (count($cekdapur->result()) > 0) {
                foreach($q_cek_login->result() as $qad){
                    $sess_data['logged_in'] = 'yesGetMeLogin';
                    $sess_data['id_user'] = $qad->id_user;
                    $sess_data['username'] = $qad->username;
                    $sess_data['nama_pengguna'] = $qad->nama_pengguna;
                    $sess_data['level'] = $qad->level;
                    $sess_data['id_lembaga'] = $qad->id_lembaga;
                    $this->session->set_userdata($sess_data);
                }
                header('location:'.base_url().'user/dashboard');
            } else {
                $this->session->set_flashdata('result_login', 'Username atau Password yang anda masukkan salah.');
                return FALSE;
            }
        }
        else
        {
            $this->session->set_flashdata('result_login', 'Username atau Password yang anda masukkan salah.');
            return FALSE;
        }
    }
}