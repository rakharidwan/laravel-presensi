<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan extends CI_Controller {

	public function __construct()
    {
        parent::__construct();

    }

	public function index()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{			
			$data = array(
				'nama' => $this->session->userdata('nama'), 
				'list_pegawai' => $this->model->GetKaryawanJab("order by id_kar desc")->result_array()
			);
			$this->load->view('inc/head', $data);
			$this->load->view('laporan/index', $data);
			$this->load->view('inc/footer');
		}
	}

	public function export()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{	
			$jabatan = $this->db->get('tb_jabatan');
			if ($this->input->post('karyawan') == 'all') {
						$kehadiran_kar = $this->model->GetKaryawanAbs("where r.tanggal between'".$_POST['dari']."' and '".$_POST['sampai']."' order by id_kar desc")->result_array();
						$filename = "presensi-".$_POST['dari']."-s/d-".$_POST['sampai']."-semua-karyawan";
					} else {
						$kehadiran_kar = $this->model->GetKaryawanAbs("where p.nippos = '".$_POST['karyawan']."' and r.tanggal between'".$_POST['dari']."' and '".$_POST['sampai']."'")->result_array();
						$filename = "presensi-".$_POST['dari']."-s/d-".$_POST['sampai']."-".$_POST['karyawan'];
					}		
			$data = array(
				'kehadiran_kar' => $kehadiran_kar,
				'nama' => $this->session->userdata('nama'),	
				'filename' => $filename,
				'jabatan' => $jabatan
			);

			$this->load->view('laporan/export', $data);
		}
	}
}
