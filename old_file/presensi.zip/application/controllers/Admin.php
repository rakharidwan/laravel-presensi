<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->model('admin_model');

    }

	public function index()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			header('location:'.base_url().'admin/dashboard');
		}
	}

	public function login(){
		$data = array(
			'nama_user' => $this->input->post('nama_user', TRUE),
			'pass_user' => md5($this->input->post('pass_user', TRUE)),
			);
		
		$hasil = $this->model->GetUser($data);
		if (count($hasil->result()) == 1) {
			foreach ($hasil->result() as $sess) {
				$sess_data['id_user'] = $sess->id_user;
				$sess_data['nama_user'] = $sess->nama_user;
				$sess_data['nama'] = $sess->nama;
				$sess_data['level'] = $sess->level;
				$sess_data['pass_user'] = md5($sess->pass_user);
				$this->session->set_userdata($sess_data);
			}
			if ($this->session->userdata('level')=='1') {
				$this->session->set_userdata('useradmin', $sess_data);
				redirect(base_url()."admin/dashboard");
			}
			else{
				$this->session->set_userdata('pasartungging', $sess_data);
				redirect(base_url()."admin/login");
			}		
		}
		else {
			$data['info']='<div style="color:red">PERIKSA KEMBALI NAMA PENGGUNA DAN PASSWORD ANDA!</div>';

			$this->load->view("login", $data);
		}
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect(base_url().'admin');
	}

	public function dashboard()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$jumlahkaryawan = $this->pegawai_model->jumlahkaryawan();
			$data = array(
				'jumlahkaryawan' => $jumlahkaryawan,
				'nama' => $this->session->userdata('nama'),	
				'list_pegawai' => $this->model->GetKaryawanJab("order by id_kar desc")->result_array(),
				'presensiterkini' => $this->model->GetKaryawanAbs("where tanggal = '".date("Y-m-d")."' order by id_abs desc limit 5")->result_array(),
				'jumlahpresensihariini' => $this->pegawai_model->countpresensihariini()
			);
			$this->load->view('inc/head', $data);
			$this->load->view('admin/dashboard', $data);
			$this->load->view('inc/footer');
		}
	}

	public function ubah()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$user['id_user'] = $this->session->userdata('id_user');
			$admin = $this->db->get_where('tb_login', $user);
			foreach ($admin->result() as $adm) {
				$data = array(
					'id_user' => $adm->id_user,	
					'nama' => $adm->nama,	
					'nama_user' => $adm->nama_user	
				);
			}
			$this->load->view('inc/head', $data);
			$this->load->view('admin/ubah', $data);
			$this->load->view('inc/footer');
		}
	}

	public function update()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
		$id_user = $this->input->post("id_user");
		$user['id_user'] = $id_user;
		$nama_user = $this->input->post('nama_user');
		$nama = $this->input->post('nama'); 
		$passlama = $this->input->post('passlama');
		$passbaru = $this->input->post('passbaru');
		$konfirpassbaru = $this->input->post('konfirpassbaru');
		$datalama = $this->db->get_where('tb_login', $user);
		foreach ($datalama->result() as $dl) {
			if(md5($passlama) == $dl->pass_user){
				if ($passbaru == $konfirpassbaru) {
					$data = array(
						'nama_user' => $nama_user,
						'nama' => $nama,
						'pass_user' => md5($passbaru),
				);
			
				$res = $this->model->Update("tb_login", $data, "id_user = '$id_user'");
				if($res>=0){
					$this->session->set_flashdata("sukses", "<div class='alert alert-success'><strong>Update data BERHASIL di lakukan</strong></div>");
					header('location:'.base_url().'admin/logout');
					}else{
					$this->session->set_flashdata("alert", "<div class='alert alert-danger'><strong>Update data GAGAL di lakukan</strong></div>");
					header('location:'.base_url().'admin/ubah');
					}
				} else {
					$this->session->set_flashdata("alert", "<div class='alert alert-danger'><strong>Konfirmasi password tidak sesuai</strong></div>");
					header('location:'.base_url().'admin/ubah');
				}
			} else {
					$this->session->set_flashdata("alert", "<div class='alert alert-danger'><strong>Password lama salah</strong></div>");
					header('location:'.base_url().'admin/ubah');
			}
		}
	}
	}
}
