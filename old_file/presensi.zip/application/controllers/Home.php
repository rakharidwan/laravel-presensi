<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	var $limit=10;
	var $offset=10;	

	public function __construct()
    {
        parent::__construct();

    } 
 
	public function index($limit='',$offset=''){		 
		$data['info']='';  
		$data['judul']='';
		$data['view']='masuk';
		$data['pegawai']='masuk';
		$data['btnmasuk']='';
		$jamsekarang = mktime(date("H"), date("i"), date("s"),date("m"), date("d"), date("Y"));
		$jamkerja = mktime(8,1,0,date("m"), date("d"), date("Y"));
		$selisih = $jamsekarang - $jamkerja;
		if ($selisih <= 0 ) {
			$data['pesan'] = "<input type='hidden' name='pesan' id='pesan'><br>";
		} else {
			$data['pesan'] = "<input type='text' class='form-control' name='pesan' id='pesan' placeholder='Sampaikan pesan'/><br>";
		}
		
		$this->load->view('index',$data);  
	}
	public function cekMasuk(){
		$this->pegawai_model->cekMasuk();
	}

	public function cekPulang(){
		$this->pegawai_model->cekPulang();
	}

	public function Masuk(){
		$this->pegawai_model->Masuk();
	}

	public function Pulang(){
		$this->pegawai_model->Pulang();
	}

	public function cekHadir(){
		$this->pegawai_model->cekHadir();
	}

	public function listabsen($limit='',$offset=''){
		$data['judul']='Histori Presensi Pegawai';
		/* VAGINATION */
		if($limit==''){ $limit = 0; $offset=10 ;}
		if($limit!=''){ $limit = $limit ; $offset=$this->offset ;}
		$data['count']=$this->pegawai_model->count();	
		$config['base_url'] = base_url().'home/search/';
		$config['total_rows'] = $data['count'];
		$config['per_page'] = $this->limit;    
		$config['cur_tag_open'] = '<span class="pg">';
		$config['cur_tag_close'] = '</span>';		
		$this->pagination->initialize($config);
		/*----------------*/
		$data['query']=$this->pegawai_model->getListpegawai($limit,$offset);
		$data['view']='hist_absen';
		$this->load->view('index',$data);
		 
	}
	
	public function search($limit='',$offset=''){
		if($limit==''){ $limit = 0; $offset=10 ;}
		if($limit!=''){ $limit = $limit ; $offset=$this->offset ;}
		$data['count']=$this->pegawai_model->count();	
		$config['base_url'] = base_url().'home/search/';
		$config['total_rows'] = $data['count'];
		$config['per_page'] = $this->limit;    
		$config['cur_tag_open'] = '<span class="pg">';
		$config['cur_tag_close'] = '</span>';		
		$this->pagination->initialize($config);
 
		$data['query']=$this->pegawai_model->getListpegawai($limit,$offset);
		$this->load->view('hist_absen',$data);
	}
}
