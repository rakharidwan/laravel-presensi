<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Presensi extends CI_Controller {

	public function __construct()
    {
        parent::__construct();

    }

	public function index()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$data_kehadiran = $this->model->GetKaryawanAbs("where r.tanggal = '".date("Y-m-d")."' order by r.id_abs desc");
			if (count($data_kehadiran->result()) > 0) {
				foreach ($data_kehadiran->result() as $presensi) {
					$pegawaihadir[] = $presensi;
							//$pegawaibelumhadir[] = NULL;
				}
			} else {
				$pegawaihadir[] = NULL;
			}
			$list_pegawai = $this->model->GetKaryawanJab("order by p.id_kar desc");
			foreach ($list_pegawai->result() as $pegawai) {
				$data_kehadiran = $this->model->GetKaryawanAbs("where r.tanggal = '".date("Y-m-d")."' and r.nippos = '".$pegawai->nippos."'");
				if (count($data_kehadiran->result()) < 1) {
					$pegawaibelumhadir[] = $pegawai;
					//$pegawaihadir[] = NULL;
				} else {
					$pegawaibelumhadir[] = NULL;
				}

			}
			$data = array(
				//'data_absensi' => $this->model->GetKaryawanAbs("where r.tanggal = '".date("Y-m-d")."' order by id_abs desc")->result_array(),
				'nama' => $this->session->userdata('nama'),
				'list_pegawai' => $this->model->GetKaryawanJab("order by id_kar desc")->result_array(),	
				'notif' => '',
				'pegawaibelumhadir' => $pegawaibelumhadir,
				'pegawaihadir' => $pegawaihadir
			);
			
			$this->load->view('inc/head', $data);
			$this->load->view('presensi/list', $data);
			$this->load->view('inc/footer');
		}
	}

	public function inputmanual()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$data = array(
				'nama' => $this->session->userdata('nama'),	
				'list_pegawai' => $this->model->GetKaryawanJab("order by id_kar desc")->result_array(),
				'save' => ""
			);
			
			$this->load->view('inc/head', $data);	
			$this->load->view('presensi/inputmanual', $data);
			$this->load->view('inc/footer', $data);	
		}
	}

	public function submit()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$data = array(
				'nama' => $this->session->userdata('nama'),	
				'save' => $this->pegawai_model->savepresensimanual(),
			);
			$this->load->view('inc/head', $data);	
			$this->load->view('presensi/inputmanual', $data);	
			$this->load->view('inc/footer', $data);		
		}
	}

	public function tidakhadir()
	{
		$cek = $this->session->userdata('useradmin');
		if(empty($cek))
		{
			$data['info'] = $this->session->userdata('info');

			$this->load->view("login", $data);
		}
		else
		{
			$keterangan = $this->uri->segment(3);
			$nik = $this->uri->segment(4);

			if ($keterangan == "izin") {
				$keteranganinput = "IZIN";
			} else if ($keterangan == "sakit") {
				$keteranganinput = "SAKIT";
			} else if ($keterangan == "tanpaketerangan") {
				$keteranganinput = "TANPA KETERANGAN";
			} else if ($keterangan == "libur") {
				$keteranganinput = "LIBUR";
			} else if ($keterangan == "cuti") {
				$keteranganinput = "CUTI";
			}

			$data = array(
				'nippos' => $nik,
				'tanggal' => date("Y-m-d"),
				'keterangan' => $keteranganinput 
			);

			$this->db->insert('tb_absensi', $data);
			redirect(base_url()."presensi");
		}
	}
}
