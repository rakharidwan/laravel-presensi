
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>ADMIN PAGE :: APLIKASI PRESENSI KARYAWAN</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
    <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />    
    <!-- FontAwesome 4.3.0 -->
    <link href="<?php echo base_url(); ?>assets/dist/css/font-awesome-4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Ionicons 2.0.0 -->
    <!-- <link href="http://code.ionicframework.com/ionicons/2.0.0/css/ionicons.min.css" rel="stylesheet" type="text/css" />-->
    <!-- Theme style -->
    <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <!-- AdminLTE Skins. Choose a skin from the css/skins 
         folder instead of downloading all of them to reduce the load. -->
    <link href="<?php echo base_url(); ?>assets/dist/css/skins/skin-black.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url()?>assets/img/logo.png" rel="icon">
    
    <!-- iCheck -->
    <!-- <link href="plugins/iCheck/flat/blue.css" rel="stylesheet" type="text/css" /> -->

  </head>
  <body class="skin-blue">
  <!-- wrapper di bawah footer -->
    <div class="wrapper"><header class="main-header">
        <!-- Logo -->
        <a href="<?php echo base_url(); ?>dashboard" class="logo"><b>Itop</b>resence</a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <b>Selamat Datang, </b><span class="hidden-xs"><?php echo $nama; ?></span>
                </a>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <aside class="main-sidebar">
        <section class="sidebar">
         
            <a href="<?php echo base_url(); ?>admin/ubah">
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo base_url(); ?>assets/dist/img/user2-160x160.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p><?php echo $nama; ?></p>
            </div>
          </div>
        </a>
          <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MENU</li>
            <li>
              <a href="<?php echo base_url(); ?>admin/dashboard">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>jabatan">
                <i class="fa fa-sitemap"></i> <span>Jabatan</span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>karyawan">
                <i class="fa fa-users"></i> <span>Karyawan</span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-check"></i> <span>Presensi</span> 
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="<?php echo base_url(); ?>presensi/inputmanual"><i class="fa fa-circle-o"></i> Input Manual</a></li>
                <li class="active"><a href="<?php echo base_url(); ?>presensi/"><i class="fa fa-circle-o"></i> Presensi Hari Ini</a></li>
              </ul>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>laporan">
                <i class="fa fa-print"></i> <span>Laporan</span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            <li>
              <a href="<?php echo base_url(); ?>admin/logout">
                <i class="fa fa-sign-out"></i> <span>Keluar</span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
          </ul>
        </section>
      </aside>