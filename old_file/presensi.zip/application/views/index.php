<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Itopresence - Aplikasi Presensi Karyawan</title>
  <link href="<?php echo base_url()?>assets/img/logo.png" rel="icon">
  <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/dist/css/font-awesome-4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url(); ?>assets/dashio/css/style.css" rel="stylesheet">
  <link href="<?php echo base_url(); ?>assets/dashio/css/style-responsive.css" rel="stylesheet">
</head>

<body onload="startTime()">
  <div style="margin: 0px;">
    <div id="txt" style="font-family:calibri;font-size:50px;text-align:center;"></div>    
  </div>
  <div id="login-page">
    <div class="container">
      <div class="form-login">
        <h2 class="form-login-heading">SILAKAN MASUKKAN NIK ANDA</h2>
        <div class="login-wrap">
          <div id="notification"></div>
          <input type="text" maxlength="12" name="nippos" id="nippos" class="form-control" placeholder="NIK" autofocus required>
          <br>
            <?php echo $pesan; ?>
            <button class='btn btn-theme btn-block' onclick="Masuk()" id='btnmasuk' disabled="disabled">MASUK</button>
            <div class="login-social-link centered">
            <a class="btn btn-primary" onclick="cekHadir()">CEK</a>
            <a class="btn btn-warning" href = "<?php echo base_url();?>">REFRESH</a>
            </div>
          <hr>
        </div>
      </div>
    </div>
  </div>
    <script src="<?php echo base_url(); ?>assets/plugins/jQuery/jQuery-2.1.3.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>    
  <script type="text/javascript" src="<?php echo base_url(); ?>assets/dashio/lib/jquery.backstretch.min.js"></script>
</body>
<script>

$( document ).ready(function() {
    $("#nippos").on("keyup",function() {
      var maxLength = $(this).attr("maxlength");
      if(maxLength == $(this).val().length) {
      cekMasuk(); 
  } else {    
      document.getElementById("btnmasuk").disabled='true';
  }
})
});

function cekMasuk(){
      var nippos=$("#nippos").val();
      var pesan=$("#pesan").val();
    $.ajax({
      url:'<?php echo base_url(); ?>home/cekMasuk/',     
      type:'POST',
      data:"nippos="+nippos+"&pesan="+pesan,
      success:function(data){ 
      if(data=='Masuk'){
          document.getElementById("btnmasuk").innerHTML=data;  
          document.getElementById("btnmasuk").disabled='';
          document.getElementById("btnmasuk").className='btn btn-success btn-block';
          document.getElementById("btnmasuk").setAttribute("onclick", "Masuk()");         
        } else if ( data=='Pulang') {
          document.getElementById("btnmasuk").innerHTML=data;  
          document.getElementById("btnmasuk").disabled='';
          document.getElementById("btnmasuk").className='btn btn-danger btn-block'; 
          document.getElementById("btnmasuk").setAttribute("onclick", "Pulang()");
          document.getElementById("pesan").setAttribute("placeholder", "Sampaikan Syukur!"); 
        } else {
          document.getElementById("btnmasuk").disabled='true';          
        }
        }
    });   
}

function Masuk(){
      var nippos=$("#nippos").val();
      var pesan=$("#pesan").val();
    $.ajax({
      url:'<?php echo base_url(); ?>home/Masuk/',     
      type:'POST',
      data:"nippos="+nippos+"&pesan="+pesan,
      success:function(data){ 
      if(data==''){
           $( "#infodlg" ).html('NIP Tidak tersedia Harap Periksa Kembali ...');
           $( "#infodlg" ).dialog({ title:"Info...", draggable: false});  
        } else {
           $("#notification").html(data);
           $("#nippos").val("");
           $("#pesan").val("");
        }
        }
    });   

}

function Pulang(){
      var nippos=$("#nippos").val();
      var pesan=$("#pesan").val();
    $.ajax({
      url:'<?php echo base_url(); ?>home/Pulang/',     
      type:'POST',
      data:"nippos="+nippos+"&pesan="+pesan,
      success:function(data){ 
      if(data==''){
           $( "#infodlg" ).html('NIP Tidak tersedia Harap Periksa Kembali ...');
           $( "#infodlg" ).dialog({ title:"Info...", draggable: false});  
        } else {
           $("#notification").html(data);
           $("#nippos").val("");
           $("#pesan").val("");  
          document.getElementById("btnmasuk").disabled='true';
        }
        }
    });   

}

function cekHadir(){
      var nippos=$("#nippos").val();
    $.ajax({
      url:'<?php echo base_url(); ?>home/cekHadir/',     
      type:'POST',
      data:"nippos="+nippos,
      success:function(data){ 
          if(data==''){
           $( "#infodlg" ).html('NIP Tidak tersedia Harap Periksa Kembali ...');
           $( "#infodlg" ).dialog({ title:"Info...", draggable: false});           
        } else {
           $("#notification").html(data);
        }
       }
    });   
}

function startTime()
{
var today=new Date();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();

m=checkTime(m);
s=checkTime(s);
document.getElementById('txt').innerHTML=h+":"+m+":"+s;
t=setTimeout(function(){startTime()},500);
}

function checkTime(i)
{
if (i<10)
  {
  i="0" + i;
  }
return i;
}
</script>
</html>
