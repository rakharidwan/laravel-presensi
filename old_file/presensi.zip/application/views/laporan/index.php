
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
                  <div class="col-md-12">
                    <h1><b>EXPORT LAPORAN PRESENSI</b></h1>
                  </div>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-md-12">
              <div class="box">
                <div class="box-title">
                  
                </div><!-- /.box-title -->
                <div class="box-body">
                  <form action="<?php echo base_url(); ?>laporan/export/" method="POST">
                    <select class="form-control" style="width:50%" name="karyawan" required>
                      <option value="">--Pilih Karyawan--</option>
                      <option value="all"><b>SEMUA</b></option>
                      <?php $no=0; foreach($list_pegawai as $row) { $no++ ?>
                             <option value="<?php echo $row['nippos']; ?>"><?php echo $row['nama_kar']." (".$row['pekerjaan'].")"; ?></option>
                              <?php } ?>
                    </select>
                    <div class="form-group">
                      <label for="">Dari</label>
                      <input type="date" class="form-control" id="" style="width:50%"  name="dari" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="">Sampai</label>
                      <input type="date" class="form-control" id="" style="width:50%"  name="sampai" placeholder="">
                    </div>
                  <button type="submit" class="btn btn-success"><i class="fa fa-print"> Export</i></button>
                    </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>