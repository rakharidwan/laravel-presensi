<?php
	// Fungsi header dengan mengirimkan raw data excel
	header("Content-type: application/vnd-ms-excel");

 	// Mendefinisikan nama file ekspor "hasil-export.xls"
	header("Content-Disposition: attachment; filename=".$filename.".xls");

?>
<table border="1">
	<tr>
		<th>NO.</th>
		<th>NIK</th>
		<th>ENTITAS</th>
		<th>NAMA</th>
		<th>JABATAN</th>
		<th>TANGGAL</th>
		<th>JAM MASUK</th>
		<th>JAM KELUAR</th>
		<th>KETERANGAN</th>
		<th>PESAN</th>
		<th>KETERLAMBATAN</th>
	</tr>
	<?php $no=0; foreach($kehadiran_kar as $row) { $no++ ?>
                    <tr>
                      <td><?php echo $no; ?></td>
                      <td><?php echo $row['nippos']; ?></td>
                      <td><?php echo $row['pekerjaan']; ?></td>
                      <td><?php echo $row['nama_kar']; ?></td>
                      <td><?php if ($row['id_jab'] != NULL) {
                      	 foreach ($jabatan->result() as $j) {
                      	 	if ($j->id_jab == $row['id_jab']) {
                      	 		echo $j->jabatan;
                      	 	}
                      	 }
                      } ?></td>
                      <td><?php echo $row['tanggal']; ?></td>
                      <td><?php echo $row['jammasuk']; ?></td>
                      <td><?php echo $row['jamkeluar']; ?></td>
                      <td><?php echo $row['keterangan']; ?></td>
                      <td><?php echo $row['pesan']; ?></td>
                      <td><?php echo $row['keterlambatanbaca']; ?></td>
                    </tr>
                    <?php } ?>
</table>