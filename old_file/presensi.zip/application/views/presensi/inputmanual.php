
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <b>TAMBAH DATA KARYAWAN</b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <?php echo $save; ?>
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
                <i class="fa fa-plus"></i>
                <h3 class="box-title">INPUT PRESENSI MANUAL</h3>
              </div>
              <div class="box-body chat" id="chat-box">
                <!-- chat item -->
                <div class="item">
                  <form role="form" action="<?php echo base_url(); ?>presensi/submit" method="POST" enctype="multipart/form-data">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="">ID - Nama</label>
                       <select class="form-control" style="width:300px" name="nippos">
                          <option>--Pilih Karyawan--</option>
                            <?php $no=0; foreach($list_pegawai as $row) { $no++ ?>
                          <option value="<?php echo $row['nippos'] ?>"><?php echo $row['nippos']." - ".$row['nama_kar']; ?></option>
                            <?php } ?>
                      </select>
                    </div>

                    <div class="form-group">
                      <label for="">Tanggal</label>
                        <input type="date" class="form-control" value="" id="" name="tanggal" placeholder="" required>                        
                    </div>
                    <div class="form-group">
                      <label for="">Jam Masuk</label>
                        <input type="time" class="form-control" value="" id="" name="jammasuk" placeholder="">                        
                    </div>                    
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="">Jam Keluar</label>
                        <input type="time" class="form-control" value="" id="" name="jamkeluar" placeholder="">
                    </div>
                    <div class="form-group">
                      <label for="">Keterangan</label>
                        <select class="form-control" style="width:300px" name="keterangan" id="keterangan" onchange="changetextbox();" required>
                            <option>----</option>
                            <option value="HADIR">Hadir</option>
                            <option value="TELAT">Telat</option>
                            <option value="IZIN/SAKIT">Izin / Sakit</option>
                            <option value="TANPA KETERANGAN">Tanpa Keterangan</option>
                            <option value="LIBUR">Libur</option>
                            <option value="CUTI">Cuti</option>
                            <option value="LAINNYA">Lainnya</option>
                        </select>                        
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" value="" id="lainnya" name="lainnya" placeholder="" disabled="disabled">                        
                    </div>
                    
                  </div>
                  
                  
                </div><!-- /.item -->
                <div class="form-group">
                  <button type="submit" class="btn btn-primary btn-block btn-flat">Simpan</button>
                  <a href="<?php echo base_url(); ?>presensi" class="btn btn-warning btn-block btn-flat">Kembali</a>
                </div><!-- /.col -->
               </form>
              </div><!-- /.chat -->
            </div><!-- /.box (chat box) -->
          </section><!-- /.Left col -->
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
<script type="text/javascript">
  function changetextbox(){
    if ($("#keterangan").val() == "LAINNYA")  {
      $("#lainnya").removeAttr("disabled");
    } else {
      $("#lainnya").attr("disabled", "disabled");
    }
  }
</script>