<link href="<?php echo base_url(); ?>assets/dist/datatables/dataTables.bootstrap.min.css" rel="stylesheet" type="text/css" />
  <div class="content-wrapper">
    <section class="content-header">
        <h1>
          <b>Presensi Karyawan <?php echo hari(date("D")).", ".tgl_indo(date("Y-m-d")); ?></b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-md-12">
            <!-- <a style="margin-bottom:3px" href="<?php echo base_url(); ?>karyawan/addkaryawan" class="btn btn-primary no-radius dropdown-toggle"><i class="fa fa-plus"></i> TAMBAH KARYAWAN </a> -->
              <div class="box">
                <!-- <span id="pesan-flash"><?php echo $this->session->flashdata('sukses'); ?></span>
                <span id="pesan-error-flash"><?php echo $this->session->flashdata('alert'); ?></span> -->
                <div class="box-title">
                  
                </div><!-- /.box-title -->
                <div class="box-body">
                  <table id="table2" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th>NAMA</th>
                        <th>MASUK</th>
                        <th>PULANG</th>
                        <th>KETERANGAN</th>
                        <th>PESAN</th>
                        <th>TINDAKAN</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if ($pegawaihadir != NULL) {
                        foreach($pegawaihadir as $row) { ?>
                          <tr>
                        <td><?php echo $row->nama_kar." (".$row->pekerjaan.")";; ?></td>
                        <td><?php if ($row->jammasuk == NULL) {
                          echo "Tidak masuk kerja";
                        } else {
                          echo date("H:i", strtotime($row->jammasuk))." WIB"; 
                        } ?></td>
                        <td><?php if ($row->jammasuk == NULL) {
                          echo "";
                        } else if ($row->jamkeluar == NULL) {
                          echo "Belum pulang";
                        } else {
                          echo date("H:i", strtotime($row->jamkeluar))." WIB"; 
                        } ?></td>
                        <td><h3 class="label 
                          <?php
                          if ($row->keterangan == 'HADIR'){
                            echo "label-primary";
                          } else if ($row->keterangan == 'TELAT') {
                            echo "label-primary";
                          }  else if ($row->keterangan == 'IZIN') {
                            echo "label-info";
                          } else if ($row->keterangan == 'SAKIT') {
                            echo "label-warning";
                          } else if ($row->keterangan == 'TANPA KETERANGAN') {
                            echo "label-danger";
                          } else if ($row->keterangan == 'LIBUR') {
                            echo "label-success";
                          } else if ($row->keterangan == 'CUTI') {
                            echo "label-default";
                          } else  {
                            echo "label-default";
                          }
                          ?>
                          "><?php echo $row->keterangan." ".$row->keterlambatanbaca; ?></h3></td>
                        <td title="<?php echo $row->pesan; ?>"><?php echo $row->pesan; ?></td>
                        <td></td>
                      </tr>
                      <?php }  
                       } ?>
                     <?php foreach($pegawaibelumhadir as $row1) { 
                       if ($row1 != NULL) {?>
                        <tr>
                        <td><?php echo $row1->nama_kar." (".$row1->pekerjaan.")"; ?></td>
                        <td><?php echo "Belum mengisi presensi"; ?></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                          <div class="btn-group">
                            <a class="dropdown-toggle" data-toggle="dropdown" title="Izin / Sakit / Tanpa Keterangan"><small class="label label-primary"><i class="fa fa-check-square-o"></i>
                              <span class="fa fa-caret-down"></span></small></a>
                            <ul class="dropdown-menu">
                              <li><a onclick="return confirm('<?php echo $row1->nama_kar.' ('.$row1->pekerjaan.')'; ?> akan dinyatakan izin pada hari ini. Apakah Anda yakin?');"  href="<?php echo base_url(); ?>presensi/tidakhadir/izin/<?php echo $row1->nippos;?>" title="Izin"><small class="label label-info"><i class="fa fa-user"></i> Izin</small></a></li>
                              <li><a onclick="return confirm('<?php echo $row1->nama_kar.' ('.$row1->pekerjaan.')'; ?> akan dinyatakan sakit pada hari ini. Apakah Anda yakin?');"  href="<?php echo base_url(); ?>presensi/tidakhadir/sakit/<?php echo $row1->nippos;?>" title="Sakit"><small class="label label-warning"><i class="fa fa-user"></i> Sakit</small></a></li>
                              <li><a onclick="return confirm('<?php echo $row1->nama_kar.' ('.$row1->pekerjaan.')'; ?> akan dinyatakan tanpa keterangan pada hari ini. Apakah Anda yakin?');"  href="<?php echo base_url(); ?>presensi/tidakhadir/tanpaketerangan/<?php echo $row1->nippos;?>" title="Tanpa Keterangan"><small class="label label-danger"><i class="fa fa-user"></i> Tanpa Keterangan</small></a></li>
                              <li><a onclick="return confirm('<?php echo $row1->nama_kar.' ('.$row1->pekerjaan.')'; ?> akan diliburkan hari ini. Apakah Anda yakin?');"  href="<?php echo base_url(); ?>presensi/tidakhadir/libur/<?php echo $row1->nippos;?>" title="Libur"><small class="label label-success"><i class="fa fa-user"></i> Libur</small></a></li>
                              <li><a onclick="return confirm('<?php echo $row1->nama_kar.' ('.$row1->pekerjaan.')'; ?> diberi cuti pada hari ini. Apakah Anda yakin?');"  href="<?php echo base_url(); ?>presensi/tidakhadir/cuti/<?php echo $row1->nippos;?>" title="Cuti"><small class="label label-default"><i class="fa fa-user"></i> Cuti</small></a></li>
                            </ul>
                          </div>
                        </td>
                      </tr>
                  <?php   } 
                   } ?>
                    </tbody>
                  </table>
                </div>
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        <!-- Main row -->
      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->
