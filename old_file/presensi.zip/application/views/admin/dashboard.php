


      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <b>DASHBOARD</b>
          </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            
            <div class="col-lg-12 col-xs-12">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $jumlahkaryawan; ?></h3>
                  <p><b>TOTAL KARYAWAN</b></p>
                </div>
                <div class="icon">
                  <i class="fa fa-users"></i>
                </div>
                <a href="<?php echo base_url(); ?>karyawan" class="small-box-footer">Lihat <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><!-- ./col -->

          </div><!-- /.row -->
          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <section class="col-lg-12 connectedSortable">
              <!-- Chat box -->
              <div class="box box-success">
                <h3>&nbsp;&nbsp;<?php echo $jumlahpresensihariini;?> karyawan telah mengisi presensi hari ini</h3>
                  <p>&nbsp;&nbsp;<b>5 KEHADIRAN TERAKHIR HARI INI</b></p><br>   
                <div class="box-body chat" id="chat-box">
                  <!-- chat item -->
                  <?php foreach ($presensiterkini as $presensi) {
                    # code...?>
                  <div class="item">
                    <?php if ($presensi['foto'] == NULL){
                      echo "<i class='fa fa-user'></i>";
                    } else {
                      echo "<img src=".base_url()."assets/upload/".$presensi['foto']." alt='user image' class='online'/>"; 
                    }?>
                    <p class="message">
                      <a href="#" class="name">
                        <small class="text-muted pull-right"><i><?php if ($presensi['jammasuk'] == NULL) {
                          echo "Tidak masuk";
                        } else { echo "Masuk pukul ".$presensi['jammasuk']; } ?></i>, <i><?php if ($presensi['jammasuk'] == NULL) {
                          echo "";
                        } else if ($presensi['jamkeluar'] == NULL) {
                          echo "belum pulang";
                        } else { ?> pulang pukul <?php echo $presensi['jamkeluar'];  } 
                        echo " ( ".$presensi['keterangan']." ".$presensi['keterlambatanbaca']." )";?></i></small>
                        <?php echo $presensi['nama_kar'];?>
                      </a>
                      <?php echo $presensi['pekerjaan'];?>
                    </p>
                  </div><!-- /.item -->
                  <?php 
                  } ?>
                <p align="center"><a href="<?php echo base_url(); ?>presensi" class="small-box-footer">Selengkapnya <i class="fa fa-arrow-circle-right"></i></a></p>
                </div><!-- /.chat -->
              </div><!-- /.box (chat box) -->
            </section><!-- /.Left col -->
            <!-- right col (We are only adding the ID to make the widgets sortable)-->
            <section class="col-lg-5 connectedSortable">

            </section><!-- right col -->
          </div><!-- /.row (main row) -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->