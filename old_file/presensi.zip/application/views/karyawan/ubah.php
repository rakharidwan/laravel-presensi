  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <h1>
          <b>EDIT DATA KARYAWAN</b>
        </h1>
          <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol> -->
        </section>

        <!-- Main content -->
        <section class="content">
        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <section class="col-lg-12">
            <!-- Chat box -->
            <div class="box">
              <div class="box-header">
                <i class="fa fa-plus"></i>
                <h3 class="box-title">FORM EDIT KARYAWAN</h3>
              </div>
              <div class="box-body chat" id="chat-box">
                <!-- chat item -->
                <div class="item">
                  <form role="form" action="<?php echo base_url(); ?>karyawan/update" method="POST" enctype="multipart/form-data">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="">NIP POS</label>
                        <input type="hidden" class="form-control" value="<?php echo $id_kar; ?>" id="" name="id_kar" placeholder="Isika" required>
                        <input type="hidden" class="form-control" value="<?php echo $tgl_input_kar; ?>" id="" name="tgl_input_kar" placeholder="Isikan" required>
                        <input type="text" class="form-control" value="<?php echo $nippos; ?>" id="" name="nippos" placeholder="" required disabled>
                    </div>

                    <div class="form-group">
                      <label for="">Nama</label>
                        <input type="text" class="form-control" value="<?php echo $nama_kar; ?>" id="" name="nama_kar" placeholder="" required>                        
                    </div>
                    <div class="form-group">
                      <label for="">No HP</label>
                        <input type="text" class="form-control" value="<?php echo $nohp; ?>" id="" name="nohp" placeholder="">                        
                    </div>                    
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="">Jabatan</label>
                        <select name="id_jab" class="form-control">
                          <option>--Pilih Jabatan--</option>
                          <?php foreach($jabatan as $kat){
                            if(!in_array($kat['id_jab'],$label_post)){
                              ?>
                              <option value="<?php echo $kat['id_jab'] ?>"><?php echo $kat['jabatan'] ?></option>
                              <?php } else { ?>
                              <option selected="selected" value="<?php echo $kat['id_jab'] ?>"><?php echo $kat['jabatan'] ?></option>
                              <?php } } ?>
                        </select> 
                    </div>
                    <div class="form-group">
                      <label for="">Entitas</label>
                        <input type="text" class="form-control" value="<?php echo $pekerjaan; ?>" id="" name="pekerjaan" placeholder="">                        
                    </div>
                    <div class="form-group">
                      <label for="">Foto</label>
                      <input type="hidden" name="foto" value="<?php echo $foto; ?>">
                        <input type="file" class="form-control" value="" id="" name="file_upload" placeholder="">
                        <img style="width:80px;height:80px" src="<?php echo base_url(); ?>assets/upload/<?php echo $foto; ?>" class="img-circl" alt="User Image" />                        
                    </div>
                    
                  </div>
                  </div><!-- /.item -->
                <div class="form-group">
                  <button type="submit" class="btn btn-primary btn-block btn-flat">Simpan</button>
                  <a href="<?php echo base_url(); ?>karyawan" class="btn btn-warning btn-block btn-flat">Kembali</a>
                </div><!-- /.col -->
               </form>
               
              </div><!-- /.chat -->
            </div><!-- /.box (chat box) -->
          </section><!-- /.Left col -->
          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">

          </section><!-- right col -->
        </div><!-- /.row (main row) -->

      </section><!-- /.content -->
    </div><!-- /.content-wrapper -->